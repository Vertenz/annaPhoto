<?php
define("ROOT_DIR", $_SERVER['DOCUMENT_ROOT'] . "/../");