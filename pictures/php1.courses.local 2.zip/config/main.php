<?php
define("ROOT_DIR", $_SERVER['DOCUMENT_ROOT'] . "/../");
define("VIEWS_DIR", ROOT_DIR . "views/");