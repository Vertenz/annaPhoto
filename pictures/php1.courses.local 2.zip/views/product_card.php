<?php /** @var \app\models\Product $model */?>
<h1><?=$model->name?></h1>
<h1><?=$model->description?></h1>